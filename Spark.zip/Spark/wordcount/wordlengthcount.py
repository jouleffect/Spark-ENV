from pyspark import SparkConf, SparkContext, RDD

conf = SparkConf().setAppName('WordCount').setMaster("local[2]")
sc = SparkContext(conf=conf)

textFile1 = sc.textFile("/app/file1.txt")
textFile2 = sc.textFile("/app/file2.txt")

words = textFile1.union(textFile2).flatMap(lambda x: x.split(" "))

word_length = words.map(lambda s: (len(s),1))
counts = word_length.reduceByKey(lambda a,b: a + b)

for element in counts.collect():
    print(element)